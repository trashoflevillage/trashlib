/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.core.item;

import dev.architectury.registry.registries.RegistrySupplier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.dispenser.DispenserBehavior;
import net.minecraft.block.dispenser.ItemDispenserBehavior;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.Direction;
import net.minecraft.world.event.GameEvent;

public class ArchitecturySpawnEggItem extends SpawnEggItem {
    private static final Logger LOGGER = LogManager.getLogger(ArchitecturySpawnEggItem.class);
    
    private final RegistrySupplier<? extends EntityType<? extends MobEntity>> entityType;
    
    protected static DispenserBehavior createDispenseItemBehavior() {
        return new ItemDispenserBehavior() {
            @Override
            public ItemStack dispenseSilently(BlockPointer source, ItemStack stack) {
                Direction direction = source.state().get(DispenserBlock.FACING);
                EntityType<?> entityType = ((SpawnEggItem) stack.getItem()).getEntityType(source.world().getRegistryManager(), stack);
                
                try {
                    entityType.spawnFromItemStack(source.world(), stack, null, source.pos().offset(direction), SpawnReason.DISPENSER, direction != Direction.UP, false);
                } catch (Exception var6) {
                    LOGGER.error("Error while dispensing spawn egg from dispenser at {}", source.pos(), var6);
                    return ItemStack.EMPTY;
                }
                
                stack.decrement(1);
                source.world().emitGameEvent(null, GameEvent.ENTITY_PLACE, source.pos());
                return stack;
            }
        };
    }
    
    public ArchitecturySpawnEggItem(RegistrySupplier<? extends EntityType<? extends MobEntity>> entityType, Settings properties) {
        this(entityType, properties, createDispenseItemBehavior());
    }
    
    public ArchitecturySpawnEggItem(RegistrySupplier<? extends EntityType<? extends MobEntity>> entityType, Settings properties,
                                    @Nullable DispenserBehavior dispenseItemBehavior) {
        super(null, properties);
        this.entityType = Objects.requireNonNull(entityType, "entityType");
        SpawnEggItem.SPAWN_EGGS.remove(null);
        entityType.listen(type -> {
            LOGGER.debug("Registering spawn egg {} for {}", toString(),
                    Objects.toString(type.arch$registryName()));
            SpawnEggItem.SPAWN_EGGS.put(type, this);
            this.type = type;
            
            if (dispenseItemBehavior != null) {
                DispenserBlock.registerBehavior(this, dispenseItemBehavior);
            }
        });
    }
    
    @Override
    public EntityType<?> getEntityType(RegistryWrapper.WrapperLookup provider, ItemStack itemStack) {
        EntityType<?> type = super.getEntityType(provider, itemStack);
        return type == null ? entityType.get() : type;
    }
}

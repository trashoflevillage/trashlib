/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.fluid;

import com.mojang.serialization.Codec;
import dev.architectury.hooks.fluid.FluidStackHooks;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.component.ComponentChanges;
import net.minecraft.component.ComponentHolder;
import net.minecraft.component.ComponentMap;
import net.minecraft.component.ComponentType;
import net.minecraft.component.MergedComponentMap;
import net.minecraft.core.component.*;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.nbt.NbtElement;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public final class FluidStack implements ComponentHolder {
    private static final FluidStackAdapter<Object> ADAPTER = adapt(FluidStack::getValue, FluidStack::new);
    private static final FluidStack EMPTY = new FluidStack(() -> Fluids.EMPTY, 0, ComponentChanges.EMPTY);
    public static final Codec<FluidStack> CODEC = ADAPTER.codec();
    public static final PacketCodec<RegistryByteBuf, FluidStack> STREAM_CODEC = ADAPTER.streamCodec();
    
    private final Object value;
    
    private FluidStack(Supplier<Fluid> fluid, long amount, ComponentChanges patch) {
        this(ADAPTER.create(fluid, amount, patch));
    }
    
    private FluidStack(Object value) {
        this.value = Objects.requireNonNull(value);
    }
    
    private Object getValue() {
        return value;
    }
    
    @ExpectPlatform
    private static FluidStackAdapter<Object> adapt(Function<FluidStack, Object> toValue, Function<Object, FluidStack> fromValue) {
        throw new AssertionError();
    }
    
    @ApiStatus.Internal
    public interface FluidStackAdapter<T> {
        T create(Supplier<Fluid> fluid, long amount, @Nullable ComponentChanges patch);
        
        Supplier<Fluid> getRawFluidSupplier(T object);
        
        Fluid getFluid(T object);
        
        long getAmount(T object);
        
        void setAmount(T object, long amount);
        
        ComponentChanges getPatch(T value);
        
        MergedComponentMap getComponents(T value);
        
        void applyComponents(T value, ComponentChanges patch);
        
        void applyComponents(T value, ComponentMap patch);
        
        @Nullable <D> D set(T value, ComponentType<? super D> type, @Nullable D component);
        
        @Nullable <D> D remove(T value, ComponentType<? extends D> type);
        
        @Nullable <D> D update(T value, ComponentType<D> type, D component, UnaryOperator<D> updater);
        
        @Nullable <D, U> D update(T value, ComponentType<D> type, D component, U updateContext, BiFunction<D, U, D> updater);
        
        T copy(T value);
        
        int hashCode(T value);
        
        Codec<FluidStack> codec();
        
        PacketCodec<RegistryByteBuf, FluidStack> streamCodec();
    }
    
    public static FluidStack empty() {
        return EMPTY;
    }
    
    public static FluidStack create(Fluid fluid, long amount, ComponentChanges patch) {
        if (fluid == Fluids.EMPTY || amount <= 0) return empty();
        return create(() -> fluid, amount, patch);
    }
    
    public static FluidStack create(Fluid fluid, long amount) {
        return create(fluid, amount, ComponentChanges.EMPTY);
    }
    
    public static FluidStack create(Supplier<Fluid> fluid, long amount, ComponentChanges patch) {
        if (amount <= 0) return empty();
        return new FluidStack(fluid, amount, patch);
    }
    
    public static FluidStack create(Supplier<Fluid> fluid, long amount) {
        return create(fluid, amount, ComponentChanges.EMPTY);
    }
    
    public static FluidStack create(RegistryEntry<Fluid> fluid, long amount, ComponentChanges patch) {
        return create(fluid.value(), amount, patch);
    }
    
    public static FluidStack create(RegistryEntry<Fluid> fluid, long amount) {
        return create(fluid.value(), amount, ComponentChanges.EMPTY);
    }
    
    public static FluidStack create(FluidStack stack, long amount) {
        return create(stack.getRawFluidSupplier(), amount, stack.getPatch());
    }
    
    public static long bucketAmount() {
        return FluidStackHooks.bucketAmount();
    }
    
    public Fluid getFluid() {
        return isEmpty() ? Fluids.EMPTY : getRawFluid();
    }
    
    @Nullable
    public Fluid getRawFluid() {
        return ADAPTER.getFluid(value);
    }
    
    public Supplier<Fluid> getRawFluidSupplier() {
        return ADAPTER.getRawFluidSupplier(value);
    }
    
    public boolean isEmpty() {
        return getRawFluid() == Fluids.EMPTY || ADAPTER.getAmount(value) <= 0;
    }
    
    public long getAmount() {
        return isEmpty() ? 0 : ADAPTER.getAmount(value);
    }
    
    public void setAmount(long amount) {
        ADAPTER.setAmount(value, amount);
    }
    
    public void grow(long amount) {
        setAmount(getAmount() + amount);
    }
    
    public void shrink(long amount) {
        setAmount(getAmount() - amount);
    }
    
    public ComponentChanges getPatch() {
        return ADAPTER.getPatch(value);
    }
    
    @Override
    public MergedComponentMap getComponents() {
        return ADAPTER.getComponents(value);
    }
    
    public void applyComponents(ComponentChanges patch) {
        ADAPTER.applyComponents(value, patch);
    }
    
    public void applyComponents(ComponentMap patch) {
        ADAPTER.applyComponents(value, patch);
    }
    
    @Nullable
    public <T> T set(ComponentType<? super T> type, @Nullable T component) {
        return ADAPTER.set(value, type, component);
    }
    
    @Nullable
    public <T> T remove(ComponentType<? extends T> type) {
        return ADAPTER.remove(value, type);
    }
    
    @Nullable
    public <T> T update(ComponentType<T> type, T component, UnaryOperator<T> updater) {
        return ADAPTER.update(value, type, component, updater);
    }
    
    @Nullable
    public <T, U> T update(ComponentType<T> type, T component, U updateContext, BiFunction<T, U, T> updater) {
        return ADAPTER.update(value, type, component, updateContext, updater);
    }
    
    public Text getName() {
        return FluidStackHooks.getName(this);
    }
    
    public String getTranslationKey() {
        return FluidStackHooks.getTranslationKey(this);
    }
    
    public FluidStack copy() {
        return new FluidStack(ADAPTER.copy(value));
    }
    
    @Override
    public int hashCode() {
        return ADAPTER.hashCode(value);
    }
    
    @Override
    public boolean equals(Object o) {
        if (!(o instanceof FluidStack)) {
            return false;
        }
        return isFluidStackEqual((FluidStack) o);
    }
    
    public boolean isFluidStackEqual(FluidStack other) {
        return getFluid() == other.getFluid() && getAmount() == other.getAmount() && isComponentEqual(other);
    }
    
    public boolean isFluidEqual(FluidStack other) {
        return getFluid() == other.getFluid();
    }
    
    public boolean isComponentEqual(FluidStack other) {
        var patch = getPatch();
        var otherPatch = other.getPatch();
        return Objects.equals(patch, otherPatch);
    }
    
    public static FluidStack read(RegistryByteBuf buf) {
        return FluidStackHooks.read(buf);
    }
    
    public static Optional<FluidStack> read(RegistryWrapper.WrapperLookup provider, NbtElement tag) {
        return FluidStackHooks.read(provider, tag);
    }
    
    public void write(RegistryByteBuf buf) {
        FluidStackHooks.write(this, buf);
    }
    
    public NbtElement write(RegistryWrapper.WrapperLookup provider, NbtElement tag) {
        return FluidStackHooks.write(provider, this, tag);
    }
    
    public FluidStack copyWithAmount(long amount) {
        if (isEmpty()) return this;
        return new FluidStack(getRawFluidSupplier(), amount, getPatch());
    }
    
    @ApiStatus.Internal
    public static void init() {
        // classloading my beloved 😍
        // please don't use this by the way
    }
}

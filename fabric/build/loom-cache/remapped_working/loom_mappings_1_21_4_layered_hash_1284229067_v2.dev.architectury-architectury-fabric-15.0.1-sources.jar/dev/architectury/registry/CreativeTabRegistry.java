/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry;

import dev.architectury.extensions.injected.InjectedItemPropertiesExtension;
import dev.architectury.injectables.annotations.ExpectPlatform;
import dev.architectury.registry.registries.DeferredSupplier;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Registry for creating or modifying creative tabs.
 *
 * @see InjectedItemPropertiesExtension#arch$tab(ItemGroup) to add an item to a creative tab easily
 */
public final class CreativeTabRegistry {
    private CreativeTabRegistry() {
    }
    
    /**
     * Creates a creative tab, with a custom icon.
     * This has to be registered manually.
     *
     * @param title the title of the creative tab
     * @param icon  the icon of the creative tab
     * @return the creative tab
     */
    public static ItemGroup create(Text title, Supplier<ItemStack> icon) {
        return create(builder -> {
            builder.displayName(title);
            builder.icon(icon);
        });
    }
    
    
    /**
     * Creates a creative tab, with a configurable builder callback.
     * This has to be registered manually.
     *
     * @param callback the builder callback
     * @return the creative tab
     */
    @ExpectPlatform
    @ApiStatus.Experimental
    public static ItemGroup create(Consumer<ItemGroup.Builder> callback) {
        throw new AssertionError();
    }
    
    /**
     * Returns a tab supplier for a tab.
     *
     * @param tab the tab
     * @return the tab supplier
     */
    @ExpectPlatform
    @ApiStatus.Experimental
    public static DeferredSupplier<ItemGroup> ofBuiltin(ItemGroup tab) {
        throw new AssertionError();
    }
    
    /**
     * Returns a tab supplier for a tab to be created later.
     *
     * @param name the name of the creative tab
     * @return the tab supplier
     */
    @ExpectPlatform
    @ApiStatus.Experimental
    public static DeferredSupplier<ItemGroup> defer(Identifier name) {
        throw new AssertionError();
    }
    
    /**
     * Returns a tab supplier for a tab to be created later.
     *
     * @param name the key of the creative tab
     * @return the tab supplier
     */
    @ApiStatus.Experimental
    public static DeferredSupplier<ItemGroup> defer(RegistryKey<ItemGroup> name) {
        return defer(name.getValue());
    }
    
    @ApiStatus.Experimental
    public static void modifyBuiltin(ItemGroup tab, ModifyTabCallback filler) {
        modify(ofBuiltin(tab), filler);
    }
    
    @ExpectPlatform
    @ApiStatus.Experimental
    public static void modify(DeferredSupplier<ItemGroup> tab, ModifyTabCallback filler) {
        throw new AssertionError();
    }
    
    @ApiStatus.Experimental
    public static void appendBuiltin(ItemGroup tab, ItemConvertible... items) {
        append(ofBuiltin(tab), items);
    }
    
    @ApiStatus.Experimental
    public static <I extends ItemConvertible, T extends Supplier<I>> void appendBuiltin(ItemGroup tab, T... items) {
        appendStack(ofBuiltin(tab), Stream.of(items).map(supplier -> () -> new ItemStack(supplier.get())));
    }
    
    @ApiStatus.Experimental
    public static void appendBuiltinStack(ItemGroup tab, ItemStack... items) {
        appendStack(ofBuiltin(tab), items);
    }
    
    @ApiStatus.Experimental
    public static void appendBuiltinStack(ItemGroup tab, Supplier<ItemStack>... items) {
        appendStack(ofBuiltin(tab), items);
    }
    
    @ApiStatus.Experimental
    public static void append(DeferredSupplier<ItemGroup> tab, ItemConvertible... items) {
        appendStack(tab, Stream.of(items).map(item -> () -> new ItemStack(item)));
    }
    
    @ApiStatus.Experimental
    public static <I extends ItemConvertible, T extends Supplier<I>> void append(DeferredSupplier<ItemGroup> tab, T... items) {
        appendStack(tab, Stream.of(items).map(supplier -> () -> new ItemStack(supplier.get())));
    }
    
    @ApiStatus.Experimental
    public static void appendStack(DeferredSupplier<ItemGroup> tab, ItemStack... items) {
        appendStack(tab, Stream.of(items).map(supplier -> () -> supplier));
    }
    
    @ExpectPlatform
    @ApiStatus.Experimental
    public static void appendStack(DeferredSupplier<ItemGroup> tab, Supplier<ItemStack> item) {
        throw new AssertionError();
    }
    
    @ApiStatus.Experimental
    public static void appendStack(DeferredSupplier<ItemGroup> tab, Supplier<ItemStack>... items) {
        for (Supplier<ItemStack> item : items) {
            appendStack(tab, item);
        }
    }
    
    @ApiStatus.Experimental
    public static void appendStack(DeferredSupplier<ItemGroup> tab, Stream<Supplier<ItemStack>> items) {
        items.forEach(item -> appendStack(tab, item));
    }
    
    @ApiStatus.Experimental
    public static void append(RegistryKey<ItemGroup> tab, ItemConvertible... items) {
        appendStack(defer(tab), Stream.of(items).map(item -> () -> new ItemStack(item)));
    }
    
    @ApiStatus.Experimental
    public static <I extends ItemConvertible, T extends Supplier<I>> void append(RegistryKey<ItemGroup> tab, T... items) {
        appendStack(defer(tab), Stream.of(items).map(supplier -> () -> new ItemStack(supplier.get())));
    }
    
    @ApiStatus.Experimental
    public static void appendStack(RegistryKey<ItemGroup> tab, ItemStack... items) {
        appendStack(defer(tab), Stream.of(items).map(supplier -> () -> supplier));
    }
    
    @ApiStatus.Experimental
    public static void appendStack(RegistryKey<ItemGroup> tab, Supplier<ItemStack> item) {
        appendStack(defer(tab), item);
    }
    
    @ApiStatus.Experimental
    public static void appendStack(RegistryKey<ItemGroup> tab, Supplier<ItemStack>... items) {
        appendStack(defer(tab), items);
    }
    
    @ApiStatus.Experimental
    public static void appendStack(RegistryKey<ItemGroup> tab, Stream<Supplier<ItemStack>> items) {
        appendStack(defer(tab), items);
    }
    
    @FunctionalInterface
    public interface ModifyTabCallback {
        void accept(FeatureSet flags, CreativeTabOutput output, boolean canUseGameMasterBlocks);
    }
}

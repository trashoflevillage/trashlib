/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.mixin.forge.client;

import dev.architectury.event.events.client.ClientRecipeUpdateEvent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.client.network.ClientConnectionState;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.s2c.play.RecipeBookAddS2CPacket;
import net.minecraft.network.packet.s2c.play.RecipeBookRemoveS2CPacket;
import net.minecraft.network.packet.s2c.play.SynchronizeRecipesS2CPacket;
import net.minecraft.recipe.RecipeManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class MixinClientPacketListener extends ClientCommonNetworkHandler {
    @Shadow
    private ClientWorld level;
    
    @Shadow
    public abstract RecipeManager recipes();
    
    @Unique
    private ClientPlayerEntity tmpPlayer;
    
    protected MixinClientPacketListener(MinecraftClient minecraft, ClientConnection connection, ClientConnectionState commonListenerCookie) {
        super(minecraft, connection, commonListenerCookie);
    }
    
    @Inject(method = "handleUpdateRecipes", at = @At("RETURN"))
    private void handleUpdateRecipes(SynchronizeRecipesS2CPacket clientboundUpdateRecipesPacket, CallbackInfo ci) {
        ClientRecipeUpdateEvent.EVENT.invoker().update(recipes());
    }
    
    @Inject(method = "handleRecipeBookAdd", at = @At("RETURN"))
    private void handleRecipeBookAdd(RecipeBookAddS2CPacket packet, CallbackInfo ci) {
        ClientRecipeUpdateEvent.ADD.invoker().add(recipes(), packet.entries());
    }
    
    @Inject(method = "handleRecipeBookRemove", at = @At("RETURN"))
    private void handleRecipeBookRemove(RecipeBookRemoveS2CPacket packet, CallbackInfo ci) {
        ClientRecipeUpdateEvent.REMOVE.invoker().remove(recipes(), packet.recipes());
    }
}

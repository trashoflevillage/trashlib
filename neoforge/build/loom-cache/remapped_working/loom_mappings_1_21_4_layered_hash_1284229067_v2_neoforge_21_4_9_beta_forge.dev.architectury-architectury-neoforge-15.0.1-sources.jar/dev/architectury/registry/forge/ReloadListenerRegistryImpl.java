/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.forge;

import com.google.common.collect.Lists;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ReloadableResourceManagerImpl;
import net.minecraft.resource.ResourceReloader;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.AddReloadListenerEvent;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;

public class ReloadListenerRegistryImpl {
    private static List<ResourceReloader> serverDataReloadListeners = Lists.newArrayList();
    
    static {
        NeoForge.EVENT_BUS.addListener(ReloadListenerRegistryImpl::addReloadListeners);
    }
    
    public static void register(ResourceType type, ResourceReloader listener, @Nullable Identifier listenerId, Collection<Identifier> dependencies) {
        if (type == ResourceType.SERVER_DATA) {
            serverDataReloadListeners.add(listener);
        } else if (type == ResourceType.CLIENT_RESOURCES) {
            registerClient(listener);
        }
    }
    
    @OnlyIn(Dist.CLIENT)
    private static void registerClient(ResourceReloader listener) {
        ((ReloadableResourceManagerImpl) MinecraftClient.getInstance().getResourceManager()).registerReloader(listener);
    }
    
    public static void addReloadListeners(AddReloadListenerEvent event) {
        for (ResourceReloader listener : serverDataReloadListeners) {
            event.addListener(listener);
        }
    }
}

/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.core.fluid.forge.imitator;

import com.google.common.base.MoreObjects;
import dev.architectury.core.fluid.ArchitecturyFluidAttributes;
import dev.architectury.hooks.client.forge.ClientExtensionsRegistryImpl;
import dev.architectury.hooks.fluid.forge.FluidStackHooksForge;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.common.SoundAction;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

import static net.minecraft.sound.SoundEvents.ITEM_BUCKET_EMPTY;
import static net.minecraft.sound.SoundEvents.ITEM_BUCKET_FILL;

class ArchitecturyFluidAttributesForge extends FluidType {
    private final ArchitecturyFluidAttributes attributes;
    private final String defaultTranslationKey;
    
    public ArchitecturyFluidAttributesForge(Properties builder, Fluid fluid, ArchitecturyFluidAttributes attributes) {
        super(addArchIntoBuilder(builder, attributes));
        this.attributes = attributes;
        this.defaultTranslationKey = Util.createTranslationKey("fluid", Registries.FLUID.getId(fluid));
        if (Platform.getEnvironment() == Env.CLIENT) {
            this.registerClient();
        }
    }
    
    private static Properties addArchIntoBuilder(Properties builder, ArchitecturyFluidAttributes attributes) {
        builder.lightLevel(attributes.getLuminosity())
                .density(attributes.getDensity())
                .temperature(attributes.getTemperature())
                .rarity(attributes.getRarity())
                .canConvertToSource(attributes.canConvertToSource())
                .viscosity(attributes.getViscosity());
        return builder;
    }
    
    @Override
    public ItemStack getBucket(FluidStack stack) {
        Item item = attributes.getBucketItem();
        return item == null ? super.getBucket(stack) : new ItemStack(item);
    }
    
    @OnlyIn(Dist.CLIENT)
    public void registerClient() {
        ClientExtensionsRegistryImpl.register(event -> {
            if (event != null) {
                event.registerFluidType(initializeClient(), this);
            } else {
                try {
                    Class<?> clazz = Class.forName("net.neoforged.neoforge.client.extensions.common.ClientExtensionsManager");
                    Field field = clazz.getDeclaredField("FLUID_TYPE_EXTENSIONS");
                    field.setAccessible(true);
                    Method method = clazz.getDeclaredMethod("register", Object.class, Map.class, Object[].class);
                    method.setAccessible(true);
                    method.invoke(null, initializeClient(), (Map<?, ?>) field.get(null), new Object[]{this});
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    @OnlyIn(Dist.CLIENT)
    public IClientFluidTypeExtensions initializeClient() {
        return new IClientFluidTypeExtensions() {
            @Override
            public int getTintColor() {
                return attributes.getColor();
            }
            
            @Override
            public Identifier getStillTexture() {
                return attributes.getSourceTexture();
            }
            
            @Override
            public Identifier getFlowingTexture() {
                return attributes.getFlowingTexture();
            }
            
            @Override
            @Nullable
            public Identifier getOverlayTexture() {
                return attributes.getOverlayTexture();
            }
            
            @Override
            public Identifier getStillTexture(FluidState state, BlockRenderView getter, BlockPos pos) {
                return attributes.getSourceTexture(state, getter, pos);
            }
            
            @Override
            public Identifier getFlowingTexture(FluidState state, BlockRenderView getter, BlockPos pos) {
                return attributes.getFlowingTexture(state, getter, pos);
            }
            
            @Override
            @Nullable
            public Identifier getOverlayTexture(FluidState state, BlockRenderView getter, BlockPos pos) {
                return attributes.getOverlayTexture(state, getter, pos);
            }
            
            @Override
            public int getTintColor(FluidState state, BlockRenderView getter, BlockPos pos) {
                return attributes.getColor(state, getter, pos);
            }
            
            @Override
            public int getTintColor(FluidStack stack) {
                return attributes.getColor(convertSafe(stack));
            }
            
            @Override
            public Identifier getStillTexture(FluidStack stack) {
                return attributes.getSourceTexture(convertSafe(stack));
            }
            
            @Override
            public Identifier getFlowingTexture(FluidStack stack) {
                return attributes.getFlowingTexture(convertSafe(stack));
            }
            
            @Override
            @Nullable
            public Identifier getOverlayTexture(FluidStack stack) {
                return attributes.getOverlayTexture(convertSafe(stack));
            }
        };
    }
    
    @Override
    public int getLightLevel(FluidStack stack) {
        return attributes.getLuminosity(convertSafe(stack));
    }
    
    @Override
    public int getLightLevel(FluidState state, BlockRenderView level, BlockPos pos) {
        return attributes.getLuminosity(convertSafe(state), level, pos);
    }
    
    @Override
    public int getDensity(FluidStack stack) {
        return attributes.getDensity(convertSafe(stack));
    }
    
    @Override
    public int getDensity(FluidState state, BlockRenderView level, BlockPos pos) {
        return attributes.getDensity(convertSafe(state), level, pos);
    }
    
    @Override
    public int getTemperature(FluidStack stack) {
        return attributes.getTemperature(convertSafe(stack));
    }
    
    @Override
    public int getTemperature(FluidState state, BlockRenderView level, BlockPos pos) {
        return attributes.getTemperature(convertSafe(state), level, pos);
    }
    
    @Override
    public int getViscosity(FluidStack stack) {
        return attributes.getViscosity(convertSafe(stack));
    }
    
    @Override
    public int getViscosity(FluidState state, BlockRenderView level, BlockPos pos) {
        return attributes.getViscosity(convertSafe(state), level, pos);
    }
    
    @Override
    public Rarity getRarity() {
        return attributes.getRarity();
    }
    
    @Override
    public Rarity getRarity(FluidStack stack) {
        return attributes.getRarity(convertSafe(stack));
    }
    
    @Override
    public Text getDescription() {
        return attributes.getName();
    }
    
    @Override
    public Text getDescription(FluidStack stack) {
        return attributes.getName(convertSafe(stack));
    }
    
    @Override
    public String getDescriptionId() {
        return MoreObjects.firstNonNull(attributes.getTranslationKey(), defaultTranslationKey);
    }
    
    @Override
    public String getDescriptionId(FluidStack stack) {
        return MoreObjects.firstNonNull(attributes.getTranslationKey(convertSafe(stack)), defaultTranslationKey);
    }
    
    @Override
    @Nullable
    public SoundEvent getSound(SoundAction action) {
        return getSound((FluidStack) null, action);
    }
    
    @Override
    @Nullable
    public SoundEvent getSound(@Nullable FluidStack stack, SoundAction action) {
        var archStack = convertSafe(stack);
        if (ITEM_BUCKET_FILL.equals(action)) {
            return attributes.getFillSound(archStack);
        } else if (ITEM_BUCKET_EMPTY.equals(action)) {
            return attributes.getEmptySound(archStack);
        }
        return null;
    }
    
    @Override
    @Nullable
    public SoundEvent getSound(@Nullable PlayerEntity player, BlockView getter, BlockPos pos, SoundAction action) {
        if (getter instanceof BlockRenderView level) {
            if (ITEM_BUCKET_FILL.equals(action)) {
                return attributes.getFillSound(null, level, pos);
            } else if (ITEM_BUCKET_EMPTY.equals(action)) {
                return attributes.getEmptySound(null, level, pos);
            }
        }
        return getSound((FluidStack) null, action);
    }
    
    @Override
    public boolean canConvertToSource(FluidStack stack) {
        return attributes.canConvertToSource();
    }
    
    @Override
    public boolean canConvertToSource(FluidState state, WorldView reader, BlockPos pos) {
        return attributes.canConvertToSource();
    }
    
    @Nullable
    public dev.architectury.fluid.FluidStack convertSafe(@Nullable FluidStack stack) {
        return stack == null ? null : FluidStackHooksForge.fromForge(stack);
    }
    
    @Nullable
    public dev.architectury.fluid.FluidStack convertSafe(@Nullable FluidState state) {
        return state == null ? null : dev.architectury.fluid.FluidStack.create(state.getFluid(), dev.architectury.fluid.FluidStack.bucketAmount());
    }
}
